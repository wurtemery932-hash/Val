import { useEffect, useRef, useState, type CSSProperties, type FormEvent } from 'react';

type DateKind = 'coffee' | 'dinner' | 'walk';
type DatePlan = { kind: DateKind; date: string; time: string; place: string };
type Position = { x: number; y: number };

const dateIdeas: { kind: DateKind; label: string; title: string }[] = [
  { kind: 'coffee', label: 'Coffee', title: 'Coffee & a little conversation' },
  { kind: 'dinner', label: 'Dinner', title: 'Dinner, just the two of us' },
  { kind: 'walk', label: 'A walk', title: 'A walk & a little adventure' },
];

const shyMessages = [
  'The “No” button is a little shy. Just saying.',
  'Oops… looks like that button has other plans.',
  'A little hard to get, isn’t it?',
  'We could do this all day. Or… you could say yes ♡',
  'Even the button thinks we’d be cute together.',
  'Okay, it’s officially playing hide-and-seek.',
];

function Heart({ className = '', filled = false }: { className?: string; filled?: boolean }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill={filled ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M20.6 4.9c-2.1-2.1-5.5-1.9-7.5.3L12 6.4l-1.1-1.2C8.9 3 5.5 2.8 3.4 4.9c-2.1 2.2-1.9 5.5.3 7.8L12 21l8.3-8.3c2.2-2.3 2.4-5.6.3-7.8Z" />
    </svg>
  );
}

function Sparkle({ className = '' }: { className?: string }) {
  return (
    <svg className={className} width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d="M12 2c.6 6.7 3.3 9.4 10 10-6.7.6-9.4 3.3-10 10C11.4 15.3 8.7 12.6 2 12c6.7-.6 9.4-3.3 10-10Z" />
    </svg>
  );
}

function DateIcon({ kind }: { kind: DateKind }) {
  return (
    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      {kind === 'coffee' && <><path d="M4 8h13v7a5 5 0 0 1-5 5H9a5 5 0 0 1-5-5V8Z" /><path d="M17 9h2a3 3 0 0 1 0 6h-2M7 3v2m4-3v3m4-2v2M3 22h16" /></>}
      {kind === 'dinner' && <><path d="M5 3v5a3 3 0 0 0 6 0V3M8 3v18M19 21V3c-3 1-5 4-5 8h5" /></>}
      {kind === 'walk' && <><path d="M3 16h18M6 20h12M12 3v2M4.2 7.2l1.5 1.5m12.6 0 1.5-1.5M3 12h2m14 0h2" /><path d="M7 16a5 5 0 0 1 10 0" /></>}
    </svg>
  );
}

function ArrowRight() {
  return <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M4 12h15m-6-6 6 6-6 6" /></svg>;
}

function Decorations({ saidYes }: { saidYes: boolean }) {
  return (
    <div className="decorations" aria-hidden="true">
      <div className="little-sparkles"><Sparkle /><Sparkle /></div>
      <div className="floating-heart heart-one"><Heart /></div>
      <div className="floating-heart heart-two"><Heart /></div>
      <div className="handwritten-note">
        <span>{saidYes ? 'oh, happy day!' : 'psst…'}</span>
        <p>{saidYes ? <>the start of<br />something sweet.</> : <>we’d be pretty<br />cute together.</>}</p>
        <svg className="note-arrow" width="137" height="71" viewBox="0 0 137 71" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 9C16 55 70 63 124 37M108 32l18 4-7 16" /></svg>
      </div>
      <div className="flower-note">
        <svg className="flower" width="78" height="103" viewBox="0 0 78 103" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
          <path d="M39 28c-18-28 18-28 0 0-2-33 31-17 4 3 28-19 37 15 5 7 31 8 5 32-5 8 14 29-21 34-13 5-10 30-34 6-9-5-32 10-28-24 1-16-26-19 3-34 17-2Z" fill="#f4e6d9" /><circle cx="39" cy="37" r="7" fill="#e7ba99" /><path d="M39 45c5 18 2 36-2 55M41 78c10-14 23-13 24-12-1 12-11 17-24 12ZM39 87c-11-13-21-11-23-10 2 10 11 13 23 10Z" />
        </svg>
        <p>a little nervous.<br />a lot hopeful.</p>
      </div>
      <div className="tiny-heart"><Heart /></div>
    </div>
  );
}

function DatePlanner({ plan, onClose, onSave }: { plan: DatePlan | null; onClose: () => void; onSave: (plan: DatePlan) => void }) {
  const [kind, setKind] = useState<DateKind>(plan?.kind ?? 'coffee');
  const [date, setDate] = useState(plan?.date ?? '');
  const [time, setTime] = useState(plan?.time ?? '17:00');
  const [place, setPlace] = useState(plan?.place ?? '');
  const dialogRef = useRef<HTMLDivElement>(null);
  const now = new Date();
  const today = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;

  useEffect(() => {
    const previousFocus = document.activeElement as HTMLElement | null;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    dialogRef.current?.focus();
    return () => {
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus();
    };
  }, []);

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    onSave({ kind, date, time, place: place.trim() });
  }

  return (
    <div className="modal-backdrop" onClick={(event) => { if (event.target === event.currentTarget) onClose(); }}>
      <div className="date-modal" role="dialog" aria-modal="true" aria-labelledby="planner-title" ref={dialogRef} tabIndex={-1} onKeyDown={(event) => {
        if (event.key === 'Escape') onClose();
        if (event.key === 'Tab') {
          const controls = dialogRef.current?.querySelectorAll<HTMLElement>('button:not([disabled]), input:not([disabled])');
          if (!controls?.length) return;
          const first = controls[0];
          const last = controls[controls.length - 1];
          if (event.shiftKey && (document.activeElement === first || document.activeElement === dialogRef.current)) { event.preventDefault(); last.focus(); }
          else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
        }
      }}>
        <button type="button" className="close-modal" onClick={onClose} aria-label="Close date planner"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round"><path d="m6 6 12 12M18 6 6 18" /></svg></button>
        <span className="modal-heart"><Heart /></span>
        <p className="modal-eyebrow">LET’S MAKE A LITTLE MEMORY</p>
        <h2 id="planner-title">A little plan for us.</h2>
        <p className="modal-description">Nothing fancy. Just you, me, and a good time.</p>
        <form onSubmit={submit}>
          <fieldset className="date-choices">
            <legend>What sounds like us?</legend>
            <div className="date-options">
              {dateIdeas.map((idea) => <button key={idea.kind} type="button" className={`date-option ${kind === idea.kind ? 'selected' : ''}`} aria-pressed={kind === idea.kind} onClick={() => setKind(idea.kind)}><DateIcon kind={idea.kind} /><span>{idea.label}</span></button>)}
            </div>
          </fieldset>
          <div className="field-row">
            <label>A day to look forward to<input type="date" aria-label="Date of our date" min={today} value={date} onChange={(event) => setDate(event.target.value)} required /></label>
            <label>And a little time<input type="time" aria-label="Time of our date" value={time} onChange={(event) => setTime(event.target.value)} required /></label>
          </div>
          <label className="place-field">Our meeting spot <span>(optional)</span><input type="text" placeholder="Your favorite little place…" value={place} maxLength={120} onChange={(event) => setPlace(event.target.value)} /></label>
          <button className="primary-button save-plan" type="submit">Save our little plan <Heart /></button>
          <p className="modal-footnote">Just a little something to look forward to.</p>
        </form>
      </div>
    </div>
  );
}

function downloadCalendar(plan: DatePlan) {
  const start = new Date(`${plan.date}T${plan.time}`);
  const end = new Date(start.getTime() + 90 * 60 * 1000);
  const stamp = (value: Date) => value.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}/, '');
  const escape = (value: string) => value.replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/,/g, '\\,').replace(/;/g, '\\;');
  const title = dateIdeas.find((idea) => idea.kind === plan.kind)?.title ?? 'Our little date';
  const contents = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//Little Crush//Our Little Date//EN', 'BEGIN:VEVENT', `UID:${Date.now()}@littlecrush.local`, `DTSTAMP:${stamp(new Date())}`, `DTSTART:${stamp(start)}`, `DTEND:${stamp(end)}`, `SUMMARY:${escape(title)}`, `LOCATION:${escape(plan.place)}`, 'DESCRIPTION:You + me + a little time together. Made with Little Crush.', 'END:VEVENT', 'END:VCALENDAR'].join('\r\n');
  const url = URL.createObjectURL(new Blob([contents], { type: 'text/calendar;charset=utf-8' }));
  const link = document.createElement('a');
  link.href = url;
  link.download = 'our-little-date.ics';
  document.body.appendChild(link);
  link.click();
  link.remove();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export default function App() {
  const [saidYes, setSaidYes] = useState(false);
  const [dodges, setDodges] = useState(0);
  const [noPosition, setNoPosition] = useState<Position | null>(null);
  const [confetti, setConfetti] = useState(false);
  const [plannerOpen, setPlannerOpen] = useState(false);
  const [plan, setPlan] = useState<DatePlan | null>(null);
  const noRef = useRef<HTMLButtonElement>(null);
  const yesRef = useRef<HTMLButtonElement>(null);
  const lastDodge = useRef(-Infinity);

  useEffect(() => {
    if (!confetti) return;
    const timeout = window.setTimeout(() => setConfetti(false), 5200);
    return () => window.clearTimeout(timeout);
  }, [confetti]);

  useEffect(() => {
    const onResize = () => setNoPosition(null);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  function dodgeNo(pointerX?: number, pointerY?: number) {
    if (performance.now() - lastDodge.current < 180) return;
    lastDodge.current = performance.now();
    const button = noRef.current?.getBoundingClientRect();
    const yes = yesRef.current?.getBoundingClientRect();
    const width = button?.width ?? 104;
    const height = button?.height ?? 54;
    const screenWidth = window.innerWidth;
    const screenHeight = window.innerHeight;
    const xMin = 18;
    const xMax = Math.max(xMin, screenWidth - width - 18);
    const yMin = Math.min(108, screenHeight * 0.18);
    const yMax = Math.max(yMin, screenHeight - height - 78);
    const cursorX = pointerX || (button ? button.left + width / 2 : screenWidth / 2);
    const cursorY = pointerY || (button ? button.top + height / 2 : screenHeight / 2);
    let next: Position = { x: xMin, y: yMin };
    const spots = [[0.15, 0.36], [0.76, 0.64], [0.72, 0.24], [0.2, 0.76], [0.08, 0.56], [0.84, 0.43], [0.55, 0.83]];
    const offset = Math.floor(Math.random() * spots.length);
    for (let attempt = 0; attempt < 40; attempt++) {
      const spot = spots[(offset + attempt) % spots.length];
      const x = Math.max(xMin, Math.min(xMax, attempt < spots.length ? screenWidth * spot[0] : xMin + Math.random() * (xMax - xMin)));
      const y = Math.max(yMin, Math.min(yMax, attempt < spots.length ? screenHeight * spot[1] : yMin + Math.random() * (yMax - yMin)));
      const awayFromCursor = Math.hypot(x + width / 2 - cursorX, y + height / 2 - cursorY) > Math.min(170, screenWidth * 0.35);
      const coversYes = yes && x < yes.right + 30 && x + width > yes.left - 30 && y < yes.bottom + 25 && y + height > yes.top - 25;
      if (awayFromCursor && !coversYes) { next = { x, y }; break; }
    }
    setNoPosition(next);
    setDodges((value) => value + 1);
  }

  function sayYes() {
    setSaidYes(true);
    setNoPosition(null);
    setConfetti(true);
  }

  function startAgain() {
    setSaidYes(false);
    setDodges(0);
    setNoPosition(null);
    setConfetti(false);
    setPlannerOpen(false);
    setPlan(null);
  }

  const selectedIdea = plan ? dateIdeas.find((idea) => idea.kind === plan.kind) : null;
  const planDate = plan ? new Date(`${plan.date}T${plan.time}`).toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }) : '';

  return (
    <div className={`love-note ${saidYes ? 'said-yes' : ''}`}>
      <div className="paper-grain" aria-hidden="true" />
      <Decorations saidYes={saidYes} />
      <header className="site-header">
        <button type="button" className="brand" onClick={startAgain} aria-label="Little Crush — start again"><Heart /><span>little crush<span className="brand-dot">.</span></span></button>
        <div className="header-note"><Sparkle /><span className="long-note">A TINY INVITATION. A BIG FEELING.</span><span className="short-note">JUST FOR YOU</span></div>
      </header>

      <main className="main-content">
        <section className="invitation" aria-labelledby="the-question">
          <div className="bunny-art"><img src="/images/bunny-love.png" alt="Two shy little bunnies sharing a pink heart beside a love letter" width="1536" height="1024" fetchPriority="high" /></div>
          <div className="eyebrow"><span />{saidYes ? 'MY FAVORITE ANSWER, EVER' : 'FOR MY FAVORITE PERSON'}<span /></div>
          {!saidYes ? <>
            <h1 id="the-question"><span>Will you go on a</span><em>date with me?<svg className="question-underline" viewBox="0 0 410 16" fill="none" aria-hidden="true"><path d="M6 10C98 0 277 0 404 9M73 14c90-7 190-6 269-2" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" /></svg></em></h1>
            <p className="invitation-description">A little laughter, some good company,<br />and a chance to make a lovely memory.</p>
            <div className="answer-actions">
              <button ref={yesRef} className="primary-button yes-button" type="button" onClick={sayYes}>Yes, I’d love to! <Heart /></button>
              <div className="no-slot"><button ref={noRef} className={`no-button ${noPosition ? 'is-dodging' : ''}`} style={noPosition ? { left: noPosition.x, top: noPosition.y } : undefined} type="button" onPointerEnter={(event) => { if (event.pointerType === 'mouse') dodgeNo(event.clientX, event.clientY); }} onPointerDown={(event) => { event.preventDefault(); dodgeNo(event.clientX, event.clientY); }} onClick={(event) => { event.preventDefault(); dodgeNo(event.clientX, event.clientY); }} aria-label="No — this playful button runs away">No</button></div>
            </div>
            <p className="button-hint" aria-live="polite" aria-atomic="true">{shyMessages[Math.min(dodges, shyMessages.length - 1)]}</p>
          </> : <>
            <h1 id="the-question" className="success-title">It’s a <em>date!</em></h1>
            <p className="invitation-description">You just made my day.<br />Here’s to the start of something sweet.</p>
            {plan && <div className="saved-plan" role="status"><span className="saved-plan-icon"><DateIcon kind={plan.kind} /></span><div><span className="plan-eyebrow">OUR LITTLE PLAN</span><h3>{selectedIdea?.title}</h3><p>{planDate}</p>{plan.place && <p className="plan-location">{plan.place}</p>}</div><Heart /></div>}
            <div className="answer-actions success-actions">
              {plan ? <><button type="button" className="primary-button" onClick={() => downloadCalendar(plan)}><svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M16 3v4M8 3v4M3 11h18m-10 4h2" /></svg>Add to calendar</button><button type="button" className="edit-plan" onClick={() => setPlannerOpen(true)}>Edit our plan</button></> : <button type="button" className="primary-button plan-button" onClick={() => setPlannerOpen(true)}>Let’s plan our date <ArrowRight /></button>}
            </div>
            <button type="button" className="ask-again" onClick={startAgain}><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d="M3 10a9 9 0 1 1 2 9M3 4v6h6" /></svg>Ask me again</button>
          </>}
        </section>
      </main>

      <footer className="site-footer"><span>A little courage. A lot of butterflies.</span><span className="footer-love">Made with <Heart /> & hopeful thoughts.</span></footer>
      {confetti && <div className="confetti" aria-hidden="true">{Array.from({ length: 42 }, (_, index) => <span key={index} className={`confetti-piece ${index % 3 === 0 ? 'confetti-heart' : ''}`} style={{ '--x': `${(index * 37 + 5) % 100}%`, '--delay': `${(index % 8) * 0.13}s`, '--duration': `${3.3 + (index % 5) * 0.25}s`, '--rotation': `${index * 43}deg`, '--color': ['#bc617b', '#e6a698', '#d7b789', '#f2c4cf'][index % 4] } as CSSProperties}>{index % 3 === 0 ? '♥' : ''}</span>)}</div>}
      {plannerOpen && <DatePlanner plan={plan} onClose={() => setPlannerOpen(false)} onSave={(newPlan) => { setPlan(newPlan); setPlannerOpen(false); setConfetti(true); }} />}
    </div>
  );
}
